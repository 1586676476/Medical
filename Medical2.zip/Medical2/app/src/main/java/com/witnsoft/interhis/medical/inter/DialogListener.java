package com.witnsoft.interhis.medical.inter;

public interface DialogListener {
    public void refreshActivity(Object object);
}