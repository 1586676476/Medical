package com.witnsoft.interhis.medical.inter;

/**
 * Created by ${liyan} on 2017/5/9.
 */

public interface OnClick {
    void onIteClick(int position);
}
